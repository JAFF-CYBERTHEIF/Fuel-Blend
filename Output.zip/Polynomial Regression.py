# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 21:26:56 2024

@author: admin
"""

import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import PolynomialFeatures
import matplotlib.tri as mtri
import seaborn as sb

# Load your data into a pandas DataFrame
data = pd.read_excel('data.xlsx')

# Get a list of unique blend names
unique_blends = data['Fuel Blends'].unique()
Input = data.drop(['BTE (%)', 'SFC (kg/kw-h)', 'NOx (ppm)', 'Smoke (%)', 'HC (ppm)', 'CO (%)'], axis =1)

categorical_columns = data.select_dtypes(include=['object']).columns.tolist()
encoder = OneHotEncoder(sparse=False)

df = data[categorical_columns]
df_encoded = pd.get_dummies(df, dtype=int)

data = pd.concat([data, df_encoded], axis=1)

#data = data.drop("Fuel Blends", axis=1)

regression_results = {}
predictions_df = pd.DataFrame()

# Split the data into input (X) and output (y) variables
X = data.drop(['BTE (%)', 'SFC (kg/kw-h)', 'NOx (ppm)', 'Smoke (%)', 'HC (ppm)', 'CO (%)','Fuel Blends'], axis =1)
y = data[['BTE (%)', 'SFC (kg/kw-h)', 'NOx (ppm)', 'Smoke (%)', 'HC (ppm)', 'CO (%)']]

# Create polynomial features
poly_features = PolynomialFeatures(degree=2)
X_poly = poly_features.fit_transform(X)

# Create a Linear Regression model and fit it to the training data
model = LinearRegression()
model.fit(X_poly, y)

# Make predictions on the test data
y_pred = model.predict(X_poly)

# Evaluate the model's performance
mse = mean_squared_error(y, y_pred)
r2 = r2_score(y, y_pred)

print("R-Squared :", r2)
print("Mean Squared Error :",mse )

Prediction = pd.DataFrame({'BTE (%)': y_pred[:, 0],
                'SFC (kg/kw-h)': y_pred[:, 1],
                'NOx (ppm)': y_pred[:, 2],
                'Smoke (%)': y_pred[:, 3],
                'HC (ppm)': y_pred[:, 4],
                'CO (%)': y_pred[:, 5],})

predictions_df = pd.concat([Input, Prediction], axis = 1)

for i, output_column in enumerate(y.columns):
    plt.figure(figsize=(8, 6))
    plt.scatter(y[output_column], y_pred[:, i], alpha=0.5)
    plt.xlabel(f"Real {output_column}")
    plt.ylabel(f"Predicted {output_column}")
    #plt.title(f"Blend: {blend} - Real vs. Predicted {output_column}")

    # Fit a line to the scatter plot
    z = np.polyfit(y[output_column], y_pred[:, i], 1)
    p = np.poly1d(z)
    plt.plot(y[output_column], p(y[output_column]), color='red')

    plt.show()


predictions_df.to_csv('blend_predictions_with_input.csv', index=False)

df = predictions_df

output_factors = ['BTE (%)', 'SFC (kg/kw-h)', 'NOx (ppm)', 'Smoke (%)', 'HC (ppm)', 'CO (%)']

num_points = 100
# Iterate through each output factor
for blend in unique_blends:
    # Filter data for the current blend
    blend_data = data[data['Fuel Blends'] == blend]
    for output_factor in output_factors:
        # Create a 3D scatter plot for the current output factor
        fig = plt.figure(figsize=(10, 8), dpi=300)
        ax = fig.add_subplot(111, projection='3d')

        # Extract input factors and the current output factor
        x = df['CR (bar)']
        Y = df['BP (kw)']
        z = df[output_factor]

        # Create a finer mesh for triangulation
        xi = np.linspace(min(x), max(x), num_points)
        yi = np.linspace(min(Y), max(Y), num_points)
        Xi, Yi = np.meshgrid(xi, yi)

        triang = mtri.Triangulation(x, Y)

        # Interpolate the z values on the finer mesh
        interpolator = mtri.LinearTriInterpolator(triang, z)
        zi = interpolator(Xi, Yi)

        # Plot the 3D scatter plot

        ax.plot_surface(Xi, Yi, zi, cmap='jet')
        # Set labels and title
        ax.set_xlabel('CR (bar)', fontname="Times New Roman", fontsize=14, fontweight="bold")
        ax.set_ylabel('BP (kw)', fontname="Times New Roman", fontsize=14, fontweight="bold")
        ax.set_zlabel(output_factor, fontname="Times New Roman", fontsize=14, fontweight="bold")
        ax.zaxis.labelpad = -2
        ax.set_title(f'{output_factor} vs. CR (bar) and BP (kw) for ' + blend, fontname="Times New Roman", fontsize=14, fontweight="bold")
        if output_factor in ["SFC (kg/kw-h)"]:
            ax.invert_zaxis()

        plt.show()

print("Correlation heat map")
print(df.corr(numeric_only=True))
# Plotting correlation heatmap
dataplot = sb.heatmap(df.corr(numeric_only=True), cmap="coolwarm", annot=True)

plt.show()
